package kitnet.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KitnetApplication {

	public static void main(String[] args) {
		SpringApplication.run(KitnetApplication.class, args);
	}

}
