package kitnet.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KitnetApplicationTests {

	@Test
	void contextLoads() {
	}

}
